/*

USC Iovine Young Academy 178: Motion Graphics.
Object Oriented Programming Demo #2: Emergence.
by Aaron Siegel, 4/8/2018.

This example code is intended to be used as reference while learning how to
execute your own emergent and generative graphics. This code should NOT be used
as a template or starting point for ANY of your assignments.

*/



// these are global variables that can be accessed from anywhere.
var balls = [];
var ballCount = 100;
var minBallSize = 2;
var maxBallSize = 10;
var releaseRate = 100;
var lastRelease;

function setup(){
  var canvas = createCanvas(windowWidth, windowHeight);
  canvas.parent("sketch");
  frameRate(60);
  ellipseMode(CENTER);
  noStroke();
  background(0);

  // create the first ball instance to get things going.
  createBall();
}

function createBall(){
  // random diamter between min and max values.
  var d = int(random(minBallSize, maxBallSize));
  // random angle around a circle.
  var angle = random(0, TWO_PI);
  // place the ball instance somewhere on the edge of the circle.
  var x = (width/4 * cos(angle)) + width/2;
  var y = (width/4 * sin(angle)) + height/2;
  balls.push(new Ball(x, y, d));
  // keep track of when the last instance was created.
  lastRelease = millis();
}

function draw(){
  // check if a new ball instance should be created
  if(millis() - lastRelease > releaseRate){
    // create a new ball instance and add to the array.
    createBall();
  }

  // loop over all of our Ball instances every frame.
  for(var i=balls.length-1; i>=0; i--){
    // calculate the ball movement and then draw it to the screen.
    balls[i].move();
    balls[i].draw();
    // check if the ball is dead
    if(balls[i].dead){
      // remove the ball by splicing it out of the array.
      balls.splice(i,1);
    }
  }
}

function windowResized(){
  resizeCanvas(windowWidth, windowHeight);
}





class Ball {
  constructor(x, y, d){
    this.x = x;               // x and y are the position of the ball.
    this.y = y;
    this.d = d;               // d is the diameter of the ball.
    this.r = d/2;             // r is the radius of the ball.
    this.startd = d;
    this.a = 10;              // alpha value on creation.
    this.starta = this.a;
    this.xv = random(-1,1);   // xv and yv are the vectors of the ball.
    this.yv = random(-1,1);
    this.lifespan = random(2000,10000);
    this.birth = millis();
    this.dead = false;
  }

  draw(){
    // check how long the object instance has been "alive".
    if(millis() - this.birth > this.lifespan){
      // object is dead, so allow it to be killed off.
      this.dead = true;
    } else {
      // object is alive, so calculate the normalized progress value.
      var p = (millis() - this.birth) / this.lifespan;
      // reduce the diameter and alpha based on the normalized progress.
      this.d = this.startd * (1-p);
      this.a = this.starta * (1-p);
    }

    // draw an ellipse using the stored property variables.
    fill(255,this.a);
    ellipse(this.x, this.y, this.d, this.d);
  }

  move(){
    // add the vector to the position to move it slightly each frame.
    this.x += this.xv;
    this.y += this.yv;

    // add some noise to the vector to make it wiggle around.
    this.xv += random(-0.2, 0.2);
    this.yv += random(-0.2, 0.2);
  }
}

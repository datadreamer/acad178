/*

USC Iovine Young Academy 178: Motion Graphics.
Object Oriented Programming Demo #1: Ball Bounce.
by Aaron Siegel, 4/8/2018.

This example code is intended to be used as reference while learning how to
execute your own emergent and generative graphics. This code should NOT be used
as a template or starting point for ANY of your assignments.

*/



// these are global variables that can be accessed from anywhere.
var balls = [];
var ballCount = 50;
var minBallSize = 10;
var maxBallSize = 50;

// setup() runs once when the page loads.
function setup(){
  var canvas = createCanvas(windowWidth, windowHeight);
  canvas.parent("sketch");
  frameRate(60);
  ellipseMode(CENTER);

  // instantiate a bunch of Ball object instances and store them in an array.
  for(var i=0; i<ballCount; i++){
    var d = int(random(minBallSize, maxBallSize));
    var x = int(random(d, width - d));
    var y = int(random(d, height - d));
    balls.push(new Ball(x, y, d));
  }
}

// draw runs however often we specify, in this case 60 times a second.
function draw(){
  background(0,180,255);
  // loop over all of our Ball instances every frame.
  for(var i=0; i<balls.length; i++){
    // calculate the ball movement and then draw it to the screen.
    balls[i].move();
    balls[i].draw();
  }
}

function windowResized(){
  resizeCanvas(windowWidth, windowHeight);
}





class Ball {
  // the constructor() is like setup() for each object instance. It runs once.
  constructor(x, y, d){
    // copy the arguments passed in into locally stored properties using this.
    this.x = x;               // x and y are the position of the ball.
    this.y = y;
    this.d = d;               // d is the diameter of the ball.
    this.r = d/2;             // r is the radius of the ball.
    this.xv = random(-1,1);   // xv and yv are the vectors of the ball.
    this.yv = random(-1,1);
  }

  draw(){
    // draw an ellipse using the stored property variables.
    ellipse(this.x, this.y, this.d, this.d);
  }

  move(){
    // add the vector to the position to move it slightly each frame.
    this.x += this.xv;
    this.y += this.yv;

    // if the new position is above or below the window frame, flip the vector.
    if(this.x < this.r){
      this.xv *= -1;
      this.x = this.r;
    } else if(this.x > width - this.r){
      this.xv *= -1;
      this.x = width - this.r;
    }

    // if the new position is left or right of the window frame, flip the vector.
    if(this.y < this.r){
      this.yv *= -1;
      this.y = this.r;
    } else if(this.y > height - this.r){
      this.yv *= -1;
      this.y = height - this.r;
    }
  }
}
